const router = require('express').Router();
const { protect } = require('../middleware/auth');

// ─── CATEGORIES ───────────────────────────────────────────────
router.get('/categories', protect, async (req, res) => {
  try {
    const cats = await req.prisma.category.findMany({
      where: { isActive: true }, orderBy: { sortOrder: 'asc' },
      include: { _count: { select: { items: true } } }
    });
    res.json({ success: true, data: cats });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

router.post('/categories', protect, async (req, res) => {
  try {
    const { name, sortOrder } = req.body;
    const cat = await req.prisma.category.create({ data: { name, sortOrder: sortOrder || 0 } });
    res.status(201).json({ success: true, data: cat });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

router.put('/categories/:id', protect, async (req, res) => {
  try {
    const cat = await req.prisma.category.update({
      where: { id: parseInt(req.params.id) },
      data: req.body
    });
    res.json({ success: true, data: cat });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

router.delete('/categories/:id', protect, async (req, res) => {
  try {
    await req.prisma.category.update({
      where: { id: parseInt(req.params.id) }, data: { isActive: false }
    });
    res.json({ success: true, message: 'Category deleted' });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

// ─── ITEMS ────────────────────────────────────────────────────
router.get('/items', protect, async (req, res) => {
  try {
    const { categoryId, search, available } = req.query;
    const where = {};
    if (categoryId) where.categoryId = parseInt(categoryId);
    if (search) where.name = { contains: search, mode: 'insensitive' };
    if (available === 'true') where.isAvailable = true;
    const items = await req.prisma.menuItem.findMany({
      where, include: { category: true }, orderBy: { name: 'asc' }
    });
    res.json({ success: true, data: items });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

router.get('/items/:id', protect, async (req, res) => {
  try {
    const item = await req.prisma.menuItem.findUnique({
      where: { id: parseInt(req.params.id) }, include: { category: true }
    });
    if (!item) return res.status(404).json({ success: false, message: 'Item not found' });
    res.json({ success: true, data: item });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

router.post('/items', protect, async (req, res) => {
  try {
    const { name, description, price, imageUrl, categoryId } = req.body;
    const item = await req.prisma.menuItem.create({
      data: { name, description, price: parseFloat(price), imageUrl, categoryId: parseInt(categoryId) },
      include: { category: true }
    });
    res.status(201).json({ success: true, data: item });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

router.put('/items/:id', protect, async (req, res) => {
  try {
    const { name, description, price, imageUrl, categoryId, isAvailable } = req.body;
    const item = await req.prisma.menuItem.update({
      where: { id: parseInt(req.params.id) },
      data: {
        ...(name !== undefined && { name }),
        ...(description !== undefined && { description }),
        ...(price !== undefined && { price: parseFloat(price) }),
        ...(imageUrl !== undefined && { imageUrl }),
        ...(categoryId !== undefined && { categoryId: parseInt(categoryId) }),
        ...(isAvailable !== undefined && { isAvailable }),
      },
      include: { category: true }
    });
    res.json({ success: true, data: item });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

router.delete('/items/:id', protect, async (req, res) => {
  try {
    await req.prisma.menuItem.delete({ where: { id: parseInt(req.params.id) } });
    res.json({ success: true, message: 'Item deleted' });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

module.exports = router;
