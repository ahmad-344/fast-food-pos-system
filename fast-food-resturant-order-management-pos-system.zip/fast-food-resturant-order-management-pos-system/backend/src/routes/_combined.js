// tables.js
const express = require('express');
const { protect } = require('../middleware/auth');
const tablesRouter = express.Router();

tablesRouter.get('/', protect, async (req, res) => {
  try {
    const tables = await req.prisma.table.findMany({
      orderBy: { number: 'asc' },
      include: { orders: { where: { status: { in: ['PENDING','PREPARING','READY'] } }, take: 1 } }
    });
    res.json({ success: true, data: tables });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

tablesRouter.patch('/:id', protect, async (req, res) => {
  try {
    const table = await req.prisma.table.update({
      where: { id: parseInt(req.params.id) }, data: req.body
    });
    res.json({ success: true, data: table });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

// staff.js
const staffRouter = express.Router();

staffRouter.get('/', protect, async (req, res) => {
  try {
    const staff = await req.prisma.staff.findMany({
      where: { isActive: true }, orderBy: { name: 'asc' }
    });
    res.json({ success: true, data: staff });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

staffRouter.post('/', protect, async (req, res) => {
  try {
    const s = await req.prisma.staff.create({ data: req.body });
    res.status(201).json({ success: true, data: s });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

staffRouter.put('/:id', protect, async (req, res) => {
  try {
    const s = await req.prisma.staff.update({
      where: { id: parseInt(req.params.id) }, data: req.body
    });
    res.json({ success: true, data: s });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

staffRouter.delete('/:id', protect, async (req, res) => {
  try {
    await req.prisma.staff.update({
      where: { id: parseInt(req.params.id) }, data: { isActive: false }
    });
    res.json({ success: true, message: 'Staff removed' });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

// settings.js
const settingsRouter = express.Router();

settingsRouter.get('/', protect, async (req, res) => {
  try {
    const r = await req.prisma.restaurant.findUnique({
      where: { id: req.restaurant.id },
      select: { id:true, name:true, address:true, phone:true, email:true, currency:true, taxRate:true, logoUrl:true, tableCount:true }
    });
    res.json({ success: true, data: r });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

settingsRouter.put('/', protect, async (req, res) => {
  try {
    const { name, address, phone, email, currency, taxRate, logoUrl, tableCount } = req.body;
    const r = await req.prisma.restaurant.update({
      where: { id: req.restaurant.id },
      data: {
        ...(name !== undefined && { name }),
        ...(address !== undefined && { address }),
        ...(phone !== undefined && { phone }),
        ...(email !== undefined && { email }),
        ...(currency !== undefined && { currency }),
        ...(taxRate !== undefined && { taxRate: parseFloat(taxRate) }),
        ...(logoUrl !== undefined && { logoUrl }),
        ...(tableCount !== undefined && { tableCount: parseInt(tableCount) }),
      }
    });
    res.json({ success: true, data: r });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

module.exports = { tablesRouter, staffRouter, settingsRouter };
