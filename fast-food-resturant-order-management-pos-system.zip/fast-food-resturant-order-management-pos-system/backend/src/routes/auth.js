const router = require('express').Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { protect } = require('../middleware/auth');

router.post('/login', async (req, res) => {
  try {
    const { name, password } = req.body;
    if (!name || !password)
      return res.status(400).json({ success: false, message: 'Restaurant name and password required' });

    const restaurant = await req.prisma.restaurant.findFirst({
      where: { name: { equals: name, mode: 'insensitive' } }
    });
    if (!restaurant)
      return res.status(401).json({ success: false, message: 'Restaurant not found' });

    const ok = await bcrypt.compare(password, restaurant.password);
    if (!ok)
      return res.status(401).json({ success: false, message: 'Incorrect password' });

    const token = jwt.sign(
      { id: restaurant.id, name: restaurant.name },
      process.env.JWT_SECRET,
      { expiresIn: process.env.JWT_EXPIRES_IN || '30d' }
    );
    const { password: _, ...rest } = restaurant;
    res.json({ success: true, token, restaurant: rest });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

router.get('/me', protect, async (req, res) => {
  try {
    const r = await req.prisma.restaurant.findUnique({
      where: { id: req.restaurant.id },
      select: { id:true, name:true, address:true, phone:true, email:true, currency:true, taxRate:true, logoUrl:true, tableCount:true }
    });
    res.json({ success: true, restaurant: r });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

module.exports = router;
