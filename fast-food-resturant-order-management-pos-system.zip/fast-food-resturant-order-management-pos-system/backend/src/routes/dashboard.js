// dashboard.js
const router = require('express').Router();
const { protect } = require('../middleware/auth');

router.get('/stats', protect, async (req, res) => {
  try {
    const { period = 'today' } = req.query;
    const now = new Date();
    let from = new Date();
    if (period === 'today') from.setHours(0,0,0,0);
    else if (period === 'week') from.setDate(now.getDate() - 7);
    else if (period === 'month') from.setMonth(now.getMonth() - 1);

    const [totalOrders, paidOrders, revenueAgg, pendingOrders, topItems] = await Promise.all([
      req.prisma.order.count({ where: { createdAt: { gte: from }, status: { not: 'CANCELLED' } } }),
      req.prisma.order.count({ where: { createdAt: { gte: from }, paymentStatus: 'PAID' } }),
      req.prisma.order.aggregate({ where: { createdAt: { gte: from }, paymentStatus: 'PAID' }, _sum: { total: true } }),
      req.prisma.order.count({ where: { status: { in: ['PENDING','PREPARING'] } } }),
      req.prisma.orderItem.groupBy({
        by: ['menuItemId'], where: { order: { createdAt: { gte: from } } },
        _sum: { quantity: true }, orderBy: { _sum: { quantity: 'desc' } }, take: 5
      })
    ]);

    const topItemDetails = await req.prisma.menuItem.findMany({
      where: { id: { in: topItems.map(t => t.menuItemId) } },
      select: { id: true, name: true, price: true }
    });

    const topItemsMapped = topItems.map(t => ({
      ...topItemDetails.find(m => m.id === t.menuItemId),
      sold: t._sum.quantity
    }));

    // Hourly chart (last 8 hours)
    const hours = [];
    for (let i = 7; i >= 0; i--) {
      const h = new Date(); h.setHours(h.getHours() - i, 0, 0, 0);
      const hEnd = new Date(h); hEnd.setHours(h.getHours() + 1);
      const agg = await req.prisma.order.aggregate({
        where: { createdAt: { gte: h, lt: hEnd }, paymentStatus: 'PAID' },
        _sum: { total: true }
      });
      hours.push({ hour: h.getHours(), revenue: Number(agg._sum.total || 0) });
    }

    res.json({
      success: true,
      data: {
        totalOrders, paidOrders, pendingOrders,
        totalRevenue: Number(revenueAgg._sum.total || 0),
        topItems: topItemsMapped,
        hourlyChart: hours
      }
    });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

module.exports = router;
