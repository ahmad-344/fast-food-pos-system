const router = require('express').Router();
const { protect } = require('../middleware/auth');

router.get('/', protect, async (req, res) => {
  try {
    const tables = await req.prisma.table.findMany({
      orderBy: { number: 'asc' },
      include: {
        orders: {
          where: { status: { in: ['PENDING','PREPARING','READY'] } },
          select: { id: true, orderNumber: true, total: true, status: true },
          take: 1
        }
      }
    });
    res.json({ success: true, data: tables });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

router.patch('/:id', protect, async (req, res) => {
  try {
    const table = await req.prisma.table.update({
      where: { id: parseInt(req.params.id) }, data: req.body
    });
    res.json({ success: true, data: table });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

module.exports = router;
