const router = require('express').Router();
const { protect } = require('../middleware/auth');
const { createNotif } = require('./notifications');
const genOrderNum = () => `ORD-${Date.now().toString().slice(-6)}`;

router.get('/', protect, async (req, res) => {
  try {
    const { status, paymentStatus, date, limit = 50 } = req.query;
    const where = {};
    if (status) where.status = status;
    if (paymentStatus) where.paymentStatus = paymentStatus;
    if (date) { const d=new Date(date);const next=new Date(d);next.setDate(d.getDate()+1);where.createdAt={gte:d,lt:next}; }
    const orders = await req.prisma.order.findMany({ where, take:parseInt(limit), include:{items:{include:{menuItem:true}},table:true,staff:true}, orderBy:{createdAt:'desc'} });
    res.json({ success:true, data:orders });
  } catch(e){res.status(500).json({success:false,message:e.message});}
});

router.get('/:id', protect, async (req, res) => {
  try {
    const order = await req.prisma.order.findUnique({ where:{id:parseInt(req.params.id)}, include:{items:{include:{menuItem:true}},table:true,staff:true} });
    if(!order)return res.status(404).json({success:false,message:'Order not found'});
    res.json({success:true,data:order});
  } catch(e){res.status(500).json({success:false,message:e.message});}
});

router.post('/', protect, async (req, res) => {
  try {
    const {tableId,staffId,items,notes,discount=0} = req.body;
    if(!items?.length)return res.status(400).json({success:false,message:'No items'});
    const restaurant = await req.prisma.restaurant.findFirst();
    const taxRate = restaurant?.taxRate||0;
    const menuItems = await req.prisma.menuItem.findMany({where:{id:{in:items.map(i=>i.menuItemId)}}});
    const orderItems = items.map(item=>{
      const mi=menuItems.find(m=>m.id===item.menuItemId);
      if(!mi)throw new Error(`Item ${item.menuItemId} not found`);
      return {menuItemId:item.menuItemId,quantity:item.quantity,unitPrice:mi.price,total:mi.price*item.quantity,notes:item.notes};
    });
    const subtotal=orderItems.reduce((s,i)=>s+i.total,0);
    const tax=subtotal*(taxRate/100);
    const total=subtotal+tax-discount;
    const order = await req.prisma.order.create({
      data:{orderNumber:genOrderNum(),tableId:tableId?parseInt(tableId):null,staffId:staffId?parseInt(staffId):null,subtotal,tax,discount,total,notes,items:{create:orderItems}},
      include:{items:{include:{menuItem:true}},table:true,staff:true}
    });
    if(tableId)await req.prisma.table.update({where:{id:parseInt(tableId)},data:{status:'OCCUPIED'}});
    const tableLabel=order.table?`Table T${order.table.number}`:'Takeaway';
    await createNotif(req.prisma,req.io,{type:'ORDER_NEW',title:'New Order Placed',message:`${order.orderNumber} — ${tableLabel} — ${restaurant?.currency||'$'}${total.toFixed(2)}`,page:'orders',refId:order.id});
    req.io.emit('order_update',order);
    res.status(201).json({success:true,data:order});
  } catch(e){res.status(500).json({success:false,message:e.message});}
});

router.patch('/:id/status', protect, async (req, res) => {
  try {
    const {status} = req.body;
    const order = await req.prisma.order.update({where:{id:parseInt(req.params.id)},data:{status},include:{items:{include:{menuItem:true}},table:true}});
    if(status==='READY'){
      const tableLabel=order.table?`Table T${order.table.number}`:'';
      await createNotif(req.prisma,req.io,{type:'ORDER_READY',title:'Order Ready to Serve',message:`${order.orderNumber} ${tableLabel} is ready — send to table now`,page:'kitchen',refId:order.id});
    }
    req.io.emit('order_update',order);req.io.emit('kitchen_update',order);
    res.json({success:true,data:order});
  } catch(e){res.status(500).json({success:false,message:e.message});}
});

router.patch('/:id/pay', protect, async (req, res) => {
  try {
    const {paymentMethod} = req.body;
    const order = await req.prisma.order.update({where:{id:parseInt(req.params.id)},data:{paymentStatus:'PAID',paymentMethod,status:'SERVED'},include:{table:true}});
    if(order.tableId)await req.prisma.table.update({where:{id:order.tableId},data:{status:'AVAILABLE'}});
    const restaurant=await req.prisma.restaurant.findFirst();
    const tableLabel=order.table?`Table T${order.table.number}`:'';
    await createNotif(req.prisma,req.io,{type:'PAYMENT',title:'Payment Received',message:`${order.orderNumber} ${tableLabel} — ${restaurant?.currency||'$'}${Number(order.total).toFixed(2)} via ${paymentMethod||'Cash'}`,page:'orders',refId:order.id});
    req.io.emit('order_update',order);
    res.json({success:true,data:order});
  } catch(e){res.status(500).json({success:false,message:e.message});}
});

router.patch('/:id/cancel', protect, async (req, res) => {
  try {
    const order=await req.prisma.order.update({where:{id:parseInt(req.params.id)},data:{status:'CANCELLED'},include:{table:true}});
    if(order.tableId)await req.prisma.table.update({where:{id:order.tableId},data:{status:'AVAILABLE'}});
    req.io.emit('order_update',order);
    res.json({success:true,data:order});
  } catch(e){res.status(500).json({success:false,message:e.message});}
});

module.exports = router;
