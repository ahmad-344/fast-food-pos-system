const router = require('express').Router();
const { protect } = require('../middleware/auth');

// ─── Helper: create notification + emit socket ────────────────
const createNotif = async (prisma, io, { type, title, message, page, refId }) => {
  const notif = await prisma.notification.create({
    data: { type, title, message, page: page || null, refId: refId || null }
  });
  if (io) io.emit('notification', notif);
  return notif;
};
module.exports.createNotif = createNotif;

// ─── GET /api/notifications ───────────────────────────────────
router.get('/', protect, async (req, res) => {
  try {
    const { limit = 30, unreadOnly } = req.query;
    const where = unreadOnly === 'true' ? { isRead: false } : {};
    const [notifs, unreadCount] = await Promise.all([
      req.prisma.notification.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        take: parseInt(limit)
      }),
      req.prisma.notification.count({ where: { isRead: false } })
    ]);
    res.json({ success: true, data: notifs, unreadCount });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

// ─── PATCH /api/notifications/:id/read ───────────────────────
router.patch('/:id/read', protect, async (req, res) => {
  try {
    const notif = await req.prisma.notification.update({
      where: { id: parseInt(req.params.id) },
      data: { isRead: true }
    });
    req.io.emit('notif_read', { id: notif.id });
    res.json({ success: true, data: notif });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

// ─── PATCH /api/notifications/read-all ───────────────────────
router.patch('/read-all', protect, async (req, res) => {
  try {
    await req.prisma.notification.updateMany({
      where: { isRead: false },
      data: { isRead: true }
    });
    req.io.emit('notif_all_read', {});
    res.json({ success: true });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

// ─── DELETE /api/notifications/:id ───────────────────────────
router.delete('/:id', protect, async (req, res) => {
  try {
    await req.prisma.notification.delete({ where: { id: parseInt(req.params.id) } });
    res.json({ success: true });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

// ─── DELETE /api/notifications/clear-all ─────────────────────
router.delete('/clear-all', protect, async (req, res) => {
  try {
    await req.prisma.notification.deleteMany({ where: { isRead: true } });
    res.json({ success: true });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

module.exports = router;
module.exports.createNotif = createNotif;
