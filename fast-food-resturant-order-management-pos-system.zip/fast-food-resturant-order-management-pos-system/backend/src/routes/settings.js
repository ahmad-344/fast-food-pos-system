const router = require('express').Router();
const { protect } = require('../middleware/auth');

router.get('/', protect, async (req, res) => {
  try {
    const r = await req.prisma.restaurant.findUnique({
      where: { id: req.restaurant.id },
      select: { id:true, name:true, address:true, phone:true, email:true, currency:true, taxRate:true, logoUrl:true, tableCount:true }
    });
    res.json({ success: true, data: r });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

router.put('/', protect, async (req, res) => {
  try {
    const { name, address, phone, email, currency, taxRate, logoUrl, tableCount } = req.body;
    const r = await req.prisma.restaurant.update({
      where: { id: req.restaurant.id },
      data: {
        ...(name       !== undefined && { name }),
        ...(address    !== undefined && { address }),
        ...(phone      !== undefined && { phone }),
        ...(email      !== undefined && { email }),
        ...(currency   !== undefined && { currency }),
        ...(taxRate    !== undefined && { taxRate: parseFloat(taxRate) }),
        ...(logoUrl    !== undefined && { logoUrl }),
        ...(tableCount !== undefined && { tableCount: parseInt(tableCount) }),
      }
    });
    res.json({ success: true, data: r });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

module.exports = router;
