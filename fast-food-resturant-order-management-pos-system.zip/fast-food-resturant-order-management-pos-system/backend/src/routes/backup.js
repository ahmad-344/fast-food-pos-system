const router = require('express').Router();
const { protect } = require('../middleware/auth');
const { createNotif } = require('./notifications');

// ─── GET /api/backup/download ─────────────────────────────────
// Download full database as JSON
router.get('/download', protect, async (req, res) => {
  try {
    const { period = 'all' } = req.query; // all | year | month | week
    let dateFilter = {};

    if (period !== 'all') {
      const from = new Date();
      if (period === 'month')     from.setMonth(from.getMonth() - 1);
      else if (period === 'year') from.setFullYear(from.getFullYear() - 1);
      else if (period === 'week') from.setDate(from.getDate() - 7);
      else if (period === 'custom' && req.query.from) {
        dateFilter = { gte: new Date(req.query.from), lte: req.query.to ? new Date(req.query.to) : new Date() };
      }
      if (period !== 'custom') dateFilter = { gte: from };
    }

    const orderWhere = period === 'all' ? {} : { createdAt: dateFilter };

    const [restaurant, staff, categories, menuItems, tables, orders, notifications] = await Promise.all([
      req.prisma.restaurant.findFirst({ select: { id:true, name:true, address:true, phone:true, email:true, currency:true, taxRate:true, tableCount:true } }),
      req.prisma.staff.findMany(),
      req.prisma.category.findMany(),
      req.prisma.menuItem.findMany({ include: { category: { select: { name: true } } } }),
      req.prisma.table.findMany(),
      req.prisma.order.findMany({
        where: orderWhere,
        include: { items: { include: { menuItem: { select: { name: true } } } }, table: { select: { number: true } }, staff: { select: { name: true } } },
        orderBy: { createdAt: 'desc' }
      }),
      req.prisma.notification.findMany({ orderBy: { createdAt: 'desc' }, take: 500 })
    ]);

    // Summary stats
    const totalRevenue = orders.filter(o => o.paymentStatus === 'PAID').reduce((s, o) => s + o.total, 0);
    const totalOrders  = orders.length;

    const backup = {
      meta: {
        exportedAt:   new Date().toISOString(),
        exportedBy:   restaurant?.name,
        period,
        version:      '2.0.0',
        totalOrders,
        totalRevenue: totalRevenue.toFixed(2),
        currency:     restaurant?.currency || '$'
      },
      restaurant,
      staff,
      categories,
      menuItems,
      tables,
      orders,
      notifications
    };

    // Create notification for backup
    await createNotif(req.prisma, req.io, {
      type: 'BACKUP',
      title: 'Backup Downloaded',
      message: `Database backup (${period}) downloaded — ${totalOrders} orders, ${restaurant?.currency}${totalRevenue.toFixed(2)} revenue`,
      page: 'settings'
    });

    const filename = `restaurant-backup-${period}-${new Date().toISOString().split('T')[0]}.json`;
    res.setHeader('Content-Type', 'application/json');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.json(backup);
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

// ─── POST /api/backup/restore ─────────────────────────────────
// Restore from JSON backup
router.post('/restore', protect, async (req, res) => {
  try {
    const backup = req.body;
    if (!backup?.meta || !backup?.restaurant) {
      return res.status(400).json({ success: false, message: 'Invalid backup file format' });
    }

    const results = { restored: [], skipped: [], errors: [] };

    // 1. Restore categories
    if (backup.categories?.length) {
      for (const cat of backup.categories) {
        try {
          await req.prisma.category.upsert({
            where: { name: cat.name },
            update: { sortOrder: cat.sortOrder, isActive: cat.isActive },
            create: { name: cat.name, sortOrder: cat.sortOrder || 0, isActive: cat.isActive !== false }
          });
          results.restored.push(`Category: ${cat.name}`);
        } catch (e) { results.skipped.push(`Category: ${cat.name} — ${e.message}`); }
      }
    }

    // 2. Restore menu items
    if (backup.menuItems?.length) {
      for (const item of backup.menuItems) {
        try {
          const cat = await req.prisma.category.findFirst({ where: { name: item.category?.name || '' } });
          if (!cat) { results.skipped.push(`Item: ${item.name} — category not found`); continue; }
          await req.prisma.menuItem.upsert({
            where: { id: item.id },
            update: { name: item.name, description: item.description, price: item.price, imageUrl: item.imageUrl, isAvailable: item.isAvailable },
            create: { name: item.name, description: item.description, price: item.price, imageUrl: item.imageUrl, isAvailable: item.isAvailable !== false, categoryId: cat.id }
          });
          results.restored.push(`Item: ${item.name}`);
        } catch (e) { results.errors.push(`Item: ${item.name} — ${e.message}`); }
      }
    }

    // 3. Restore staff
    if (backup.staff?.length) {
      for (const s of backup.staff) {
        try {
          await req.prisma.staff.upsert({
            where: { id: s.id },
            update: { name: s.name, role: s.role, phone: s.phone },
            create: { name: s.name, role: s.role || 'WAITER', phone: s.phone }
          });
          results.restored.push(`Staff: ${s.name}`);
        } catch (e) { results.skipped.push(`Staff: ${s.name}`); }
      }
    }

    // 4. Restore orders (read-only history)
    let ordersRestored = 0;
    if (backup.orders?.length) {
      for (const order of backup.orders) {
        try {
          const exists = await req.prisma.order.findFirst({ where: { orderNumber: order.orderNumber } });
          if (exists) { results.skipped.push(`Order: ${order.orderNumber} already exists`); continue; }
          await req.prisma.order.create({
            data: {
              orderNumber:   order.orderNumber,
              status:        order.status,
              paymentStatus: order.paymentStatus,
              paymentMethod: order.paymentMethod,
              subtotal:      order.subtotal,
              tax:           order.tax,
              discount:      order.discount,
              total:         order.total,
              notes:         order.notes,
              createdAt:     new Date(order.createdAt),
              items: {
                create: (order.items || []).map(i => ({
                  quantity:  i.quantity,
                  unitPrice: i.unitPrice,
                  total:     i.total,
                  notes:     i.notes,
                  menuItemId: i.menuItemId
                }))
              }
            }
          });
          ordersRestored++;
        } catch (e) { results.errors.push(`Order ${order.orderNumber}: ${e.message}`); }
      }
      results.restored.push(`${ordersRestored} orders`);
    }

    await createNotif(req.prisma, req.io, {
      type: 'BACKUP',
      title: 'Backup Restored',
      message: `Restored from backup: ${results.restored.length} items, ${results.skipped.length} skipped`,
      page: 'settings'
    });

    res.json({
      success: true,
      message: `Restore complete! ${ordersRestored} orders restored.`,
      results
    });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

module.exports = router;
