const router = require('express').Router();
const { protect } = require('../middleware/auth');
const { createNotif } = require('./notifications');

router.get('/', protect, async (req, res) => {
  try {
    const staff = await req.prisma.staff.findMany({ where:{isActive:true}, orderBy:{name:'asc'} });
    res.json({ success:true, data:staff });
  } catch(e){res.status(500).json({success:false,message:e.message});}
});

router.post('/', protect, async (req, res) => {
  try {
    const s = await req.prisma.staff.create({ data:req.body });
    await createNotif(req.prisma, req.io, {
      type: 'STAFF',
      title: 'Staff Member Added',
      message: `${s.name} (${s.role}) has been added to the team`,
      page: 'staff',
      refId: s.id
    });
    res.status(201).json({ success:true, data:s });
  } catch(e){res.status(500).json({success:false,message:e.message});}
});

router.post('/:id/checkin', protect, async (req, res) => {
  try {
    const s = await req.prisma.staff.findUnique({ where:{id:parseInt(req.params.id)} });
    if(!s) return res.status(404).json({success:false,message:'Staff not found'});
    await createNotif(req.prisma, req.io, {
      type: 'STAFF',
      title: 'Staff Check-in',
      message: `${s.name} (${s.role}) started their shift`,
      page: 'staff',
      refId: s.id
    });
    res.json({ success:true, message:`${s.name} checked in` });
  } catch(e){res.status(500).json({success:false,message:e.message});}
});

router.put('/:id', protect, async (req, res) => {
  try {
    const s = await req.prisma.staff.update({ where:{id:parseInt(req.params.id)}, data:req.body });
    res.json({ success:true, data:s });
  } catch(e){res.status(500).json({success:false,message:e.message});}
});

router.delete('/:id', protect, async (req, res) => {
  try {
    await req.prisma.staff.update({ where:{id:parseInt(req.params.id)}, data:{isActive:false} });
    res.json({ success:true });
  } catch(e){res.status(500).json({success:false,message:e.message});}
});

module.exports = router;
