require('dotenv').config();
const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs');
const prisma = new PrismaClient();

async function main() {
  console.log('\n  Seeding database...\n');

  // ─── Restaurant ───────────────────────────────────────────
  const existing = await prisma.restaurant.findFirst();
  if (!existing) {
    await prisma.restaurant.create({
      data: {
        name: 'The Grand Table',
        password: await bcrypt.hash('admin123', 12),
        address: '123 Main Street, City',
        phone: '+1 (555) 000-0000',
        email: 'info@thegrandtable.com',
        currency: '$',
        taxRate: 10,
        tableCount: 12,
      }
    });
    console.log('  ✓ Restaurant created');
  }

  // ─── Staff ────────────────────────────────────────────────
  const staffCount = await prisma.staff.count();
  if (staffCount === 0) {
    await prisma.staff.createMany({
      data: [
        { name: 'Ahmad Khan',    role: 'MANAGER',  phone: '+1 555 001' },
        { name: 'Sara Ahmed',    role: 'CASHIER',  phone: '+1 555 002' },
        { name: 'John Miller',   role: 'WAITER',   phone: '+1 555 003' },
        { name: 'Maria Santos',  role: 'WAITER',   phone: '+1 555 004' },
        { name: 'Chef David',    role: 'CHEF',     phone: '+1 555 005' },
      ]
    });
    console.log('  ✓ Staff created');
  }

  // ─── Tables ───────────────────────────────────────────────
  const tableCount = await prisma.table.count();
  if (tableCount === 0) {
    for (let i = 1; i <= 12; i++) {
      await prisma.table.create({ data: { number: i, capacity: i <= 4 ? 2 : i <= 8 ? 4 : 6 } });
    }
    console.log('  ✓ Tables created (12 tables)');
  }

  // ─── Categories ───────────────────────────────────────────
  const catCount = await prisma.category.count();
  if (catCount === 0) {
    const cats = await prisma.category.createMany({
      data: [
        { name: 'Starters',    sortOrder: 1 },
        { name: 'Main Course', sortOrder: 2 },
        { name: 'Burgers',     sortOrder: 3 },
        { name: 'Pizza',       sortOrder: 4 },
        { name: 'Pasta',       sortOrder: 5 },
        { name: 'Salads',      sortOrder: 6 },
        { name: 'Desserts',    sortOrder: 7 },
        { name: 'Beverages',   sortOrder: 8 },
      ]
    });
    console.log('  ✓ Categories created');
  }

  // ─── Menu Items ───────────────────────────────────────────
  const itemCount = await prisma.menuItem.count();
  if (itemCount === 0) {
    const cats = await prisma.category.findMany();
    const c = (name) => cats.find(c => c.name === name).id;

    await prisma.menuItem.createMany({
      data: [
        // Starters
        { name: 'Garlic Bread',        description: 'Toasted bread with garlic butter and herbs',   price: 5.99,  categoryId: c('Starters'),    imageUrl: 'https://images.unsplash.com/photo-1573140247632-f8fd74997d5c?w=400' },
        { name: 'Chicken Wings',       description: 'Crispy wings with choice of sauce',             price: 10.99, categoryId: c('Starters'),    imageUrl: 'https://images.unsplash.com/photo-1567620832903-9fc6debc209f?w=400' },
        { name: 'Soup of the Day',     description: 'Chef\'s fresh daily soup with bread roll',      price: 7.50,  categoryId: c('Starters'),    imageUrl: 'https://images.unsplash.com/photo-1547592166-23ac45744acd?w=400' },
        { name: 'Bruschetta',          description: 'Tomato, basil and olive oil on toasted bread',  price: 8.50,  categoryId: c('Starters'),    imageUrl: 'https://images.unsplash.com/photo-1572695157366-5e585ab2b69f?w=400' },
        // Main Course
        { name: 'Grilled Salmon',      description: 'Atlantic salmon with lemon butter sauce',       price: 24.99, categoryId: c('Main Course'), imageUrl: 'https://images.unsplash.com/photo-1519708227418-c8fd9a32b7a2?w=400' },
        { name: 'Ribeye Steak',        description: '300g prime ribeye, medium rare',                price: 34.99, categoryId: c('Main Course'), imageUrl: 'https://images.unsplash.com/photo-1544025162-d76694265947?w=400' },
        { name: 'Chicken Tikka',       description: 'Tandoor chicken in aromatic spiced sauce',      price: 18.99, categoryId: c('Main Course'), imageUrl: 'https://images.unsplash.com/photo-1565557623262-b51c2513a641?w=400' },
        { name: 'Lamb Chops',          description: 'Herb-marinated lamb with mint chutney',         price: 29.99, categoryId: c('Main Course'), imageUrl: 'https://images.unsplash.com/photo-1432139555190-58524dae6a55?w=400' },
        // Burgers
        { name: 'Classic Cheeseburger',description: 'Beef patty, cheddar, lettuce, tomato',         price: 14.99, categoryId: c('Burgers'),     imageUrl: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=400' },
        { name: 'BBQ Bacon Burger',    description: 'Double patty, bacon, BBQ sauce',                price: 16.99, categoryId: c('Burgers'),     imageUrl: 'https://images.unsplash.com/photo-1553979459-d2229ba7433b?w=400' },
        { name: 'Veggie Burger',       description: 'Plant-based patty with avocado',                price: 13.99, categoryId: c('Burgers'),     imageUrl: 'https://images.unsplash.com/photo-1520072959219-c595dc870360?w=400' },
        // Pizza
        { name: 'Margherita',          description: 'San Marzano tomato, mozzarella, fresh basil',   price: 14.99, categoryId: c('Pizza'),       imageUrl: 'https://images.unsplash.com/photo-1574071318508-1cdbab80d002?w=400' },
        { name: 'Pepperoni',           description: 'Loaded with premium pepperoni slices',          price: 16.99, categoryId: c('Pizza'),       imageUrl: 'https://images.unsplash.com/photo-1628840042765-356cda07504e?w=400' },
        { name: 'BBQ Chicken Pizza',   description: 'Grilled chicken, red onion, BBQ base',         price: 17.99, categoryId: c('Pizza'),       imageUrl: 'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=400' },
        // Pasta
        { name: 'Spaghetti Carbonara', description: 'Egg, pancetta, parmesan, black pepper',        price: 15.99, categoryId: c('Pasta'),       imageUrl: 'https://images.unsplash.com/photo-1612874742237-6526221588e3?w=400' },
        { name: 'Penne Arrabbiata',    description: 'Spicy tomato sauce with fresh chilli',         price: 13.99, categoryId: c('Pasta'),       imageUrl: 'https://images.unsplash.com/photo-1621996346565-e3dbc646d9a9?w=400' },
        // Salads
        { name: 'Caesar Salad',        description: 'Romaine, croutons, parmesan, caesar dressing', price: 11.99, categoryId: c('Salads'),      imageUrl: 'https://images.unsplash.com/photo-1546793665-c74683f339c1?w=400' },
        { name: 'Greek Salad',         description: 'Feta, olives, cucumber, tomato, red onion',    price: 10.99, categoryId: c('Salads'),      imageUrl: 'https://images.unsplash.com/photo-1540189549336-e6e99c3679fe?w=400' },
        // Desserts
        { name: 'Chocolate Lava Cake', description: 'Warm chocolate cake with vanilla ice cream',   price: 8.99,  categoryId: c('Desserts'),    imageUrl: 'https://images.unsplash.com/photo-1617305855058-336d24456869?w=400' },
        { name: 'Cheesecake',          description: 'New York style with berry compote',             price: 7.99,  categoryId: c('Desserts'),    imageUrl: 'https://images.unsplash.com/photo-1565958011703-44f9829ba187?w=400' },
        { name: 'Tiramisu',            description: 'Classic Italian with mascarpone cream',         price: 8.50,  categoryId: c('Desserts'),    imageUrl: 'https://images.unsplash.com/photo-1571877227200-a0d98ea607e9?w=400' },
        // Beverages
        { name: 'Fresh Lemonade',      description: 'House-made with fresh lemons and mint',        price: 4.50,  categoryId: c('Beverages'),   imageUrl: 'https://images.unsplash.com/photo-1621263764928-df1444c5e859?w=400' },
        { name: 'Sparkling Water',     description: 'San Pellegrino 750ml',                         price: 3.50,  categoryId: c('Beverages'),   imageUrl: 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=400' },
        { name: 'Fresh Orange Juice',  description: 'Freshly squeezed, served chilled',             price: 5.50,  categoryId: c('Beverages'),   imageUrl: 'https://images.unsplash.com/photo-1621506289937-a8e4df240d0b?w=400' },
        { name: 'Espresso',            description: 'Double shot, single origin beans',             price: 3.00,  categoryId: c('Beverages'),   imageUrl: 'https://images.unsplash.com/photo-1510707577719-ae7c14805e3a?w=400' },
      ]
    });
    console.log('  ✓ Menu items created (25 items)');
  }

  console.log('\n  ─────────────────────────────────────');
  console.log('  Database ready!');
  console.log('  Login: The Grand Table / admin123');
  console.log('  ─────────────────────────────────────\n');
}

main().catch(e => { console.error(e); process.exit(1); }).finally(() => prisma.$disconnect());
