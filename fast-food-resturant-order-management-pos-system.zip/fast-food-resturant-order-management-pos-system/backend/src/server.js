require('dotenv').config();
const express = require('express');
const cors = require('cors');
const http = require('http');
const { Server } = require('socket.io');
const { PrismaClient } = require('@prisma/client');
const path = require('path');
const { createNotif } = require('./routes/notifications');

const app = express();
const server = http.createServer(app);
const prisma = new PrismaClient();

const io = new Server(server, { cors: { origin: '*' } });
io.on('connection', (socket) => {
  socket.on('join', (room) => socket.join(room));
  socket.on('order_update', (data) => io.emit('order_update', data));
  socket.on('kitchen_update', (data) => io.emit('kitchen_update', data));
});

app.use(cors({ origin:'*', methods:['GET','POST','PUT','DELETE','PATCH'], allowedHeaders:['Content-Type','Authorization'] }));
app.use(express.json({ limit:'50mb' }));
app.use(express.urlencoded({ extended:true, limit:'50mb' }));
app.use('/uploads', express.static(path.join(__dirname,'../uploads')));
app.use((req,_,next)=>{ req.prisma=prisma; req.io=io; next(); });

app.use('/api/auth',          require('./routes/auth'));
app.use('/api/dashboard',     require('./routes/dashboard'));
app.use('/api/menu',          require('./routes/menu'));
app.use('/api/orders',        require('./routes/orders'));
app.use('/api/tables',        require('./routes/tables'));
app.use('/api/staff',         require('./routes/staff'));
app.use('/api/settings',      require('./routes/settings'));
app.use('/api/notifications', require('./routes/notifications'));
app.use('/api/backup',        require('./routes/backup'));

app.get('/api/health', (_,res) => res.json({ status:'ok', app:'Restaurant POS', version:'2.0.0' }));

// Auto daily backup notification (every 24h)
setInterval(async () => {
  try {
    await createNotif(prisma, io, {
      type: 'BACKUP',
      title: 'System Backup',
      message: 'Automatic daily backup reminder — go to Settings to download your backup',
      page: 'settings'
    });
  } catch(e) {}
}, 24 * 60 * 60 * 1000);

app.use((err,_,res,__)=>{ console.error(err.stack); res.status(500).json({success:false,message:err.message}); });

const PORT = process.env.PORT || 5000;
server.listen(PORT, () => {
  console.log(`\n  Restaurant POS Server v2.0`);
  console.log(`  ─────────────────────────────`);
  console.log(`  API    : http://localhost:${PORT}/api`);
  console.log(`  Health : http://localhost:${PORT}/api/health\n`);
});
